// Centralized API base URL configuration
// Uses CRA env var with safe fallback to preserve current functionality
export const API_BASE = process.env.REACT_APP_BASE_URL;


