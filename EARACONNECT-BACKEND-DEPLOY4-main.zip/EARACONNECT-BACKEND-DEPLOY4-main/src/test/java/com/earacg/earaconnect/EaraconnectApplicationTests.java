package com.earacg.earaconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EaraconnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
